---
created: 2026-11-18T16:15
updated: 2026-11-20T15:56
---
# Comment fonctionne le bréviaire — visite guidée

Ce document explique **comment la chose est construite**, des fichiers sur l'ordinateur jusqu'au site en
ligne sur Azure. Il ne dit pas comment *se servir* du site (voir `README.md` et
`MODE-D-EMPLOI-REGLAGES.md`), mais comment il *marche*, pour qu'on puisse le reprendre, le réparer ou le
confier à quelqu'un d'autre.

---

## 1. L'idée en une image

```mermaid
flowchart LR
  subgraph Mac["Sur le Mac (atelier)"]
    S["Sources<br/>.doc, .docx, PDF des carnets,<br/>tableaux Gouzes"]
    O["outils/<br/>programmes de fabrication"]
    D["site/donnees/*.json<br/>partitions/*.jpg"]
    S --> O --> D
  end
  subgraph Azure["Sur Azure (en ligne)"]
    SWA["Static Web App<br/>breviaire-dominicain<br/>(pages, scripts, textes)"]
    ENT["Entrepôt breviairefichiers<br/>(images des partitions,<br/>données de la Bible)"]
    API["Petite fonction<br/>« signalements » + table"]
  end
  D -- "publier_azure.sh" --> SWA
  D -- "entrepot.py" --> ENT
  N["Navigateur<br/>(ordinateur, téléphone)"]
  SWA --> N
  ENT --> N
  AELF["api.aelf.org<br/>(textes propres du jour)"] --> N
  N -- "Signaler une erreur" --> API
```

Trois idées à retenir :

1. **Tout le travail lourd est fait d'avance, sur le Mac.** Les programmes du dossier `outils/` lisent
   vos fichiers Word, PDF et tableaux, et en tirent des fichiers de données (`.json`) et des images de
   partitions. On ne les relance que quand une source change.
2. **Le site lui-même ne « calcule » rien sur un serveur.** C'est un *site statique* : un paquet de
   fichiers que le navigateur télécharge. C'est **le navigateur** (Safari, Chrome…) qui assemble l'office
   du jour : il calcule la date liturgique, va chercher les textes propres sur le site de l'AELF, prend les
   psaumes dans votre traduction, et met les partitions au bon endroit.
3. **Azure ne fait qu'héberger.** Il garde les fichiers et les sert. La seule exception est une toute
   petite fonction qui reçoit les « signalements d'erreur ».

---

## 2. Le dossier, pièce par pièce

| Dossier / fichier                                                                     | À quoi il sert                                                                       | Publié en ligne ?    |
| ------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ | -------------------- |
| `site/`                                                                               | **Le site lui-même** : pages, mise en forme, programmes du navigateur, données       | oui                  |
| `site/js/`                                                                            | Les programmes qui tournent dans le navigateur (voir § 3)                            | oui                  |
| `site/donnees/`                                                                       | Psautier, Bible, calendrier, Gouzes, capitules, complies… en `.json`                 | oui                  |
| `site/css/`, `site/polices/`                                                          | Mise en page (écran, impression A5/A4) et polices Kepler                             | oui                  |
| `partitions/`                                                                         | Images des partitions découpées dans les carnets, et leurs index                     | images → entrepôt    |
| `bible/`                                                                              | La Bible (vue téléphone et interlinéaire), projet rangé à part, servi sous `/bible/` | oui                  |
| `api/`                                                                                | La fonction Azure qui reçoit les signalements                                        | oui (comme « API »)  |
| `outils/`                                                                             | Programmes de **fabrication** (lecture des sources, découpage, publication)          | non                  |
| `tests/`                                                                              | Programmes de **contrôle** (ils vérifient que rien n'est cassé)                      | non                  |
| `sources_gouzes/`, `sources_aelf/`, `*.doc`                                           | Vos documents d'origine                                                              | non                  |
| `propre_op.toml`                                                                      | Le propre de l'Ordre (fêtes OP), en clair, modifiable                                | via `propre_op.json` |
| `CLAUDE.md`                                                                           | Le **carnet de bord** technique, tenu à jour à chaque séance                         | non                  |
| `README.md`, `MODE-D-EMPLOI-…`, `CORRIGER-UNE-PARTITION.md`, `MISE-EN-LIGNE-AZURE.md` | Notices pour vous                                                                    | non                  |
| `Lancer le bréviaire.command`                                                         | Double-clic : ouvre le site sur le Mac, sans Internet pour le site                   | non                  |

---

## 3. Ce qui se passe quand on ouvre l'office du jour

Le navigateur charge `site/index.html`, qui appelle les programmes de `site/js/` dans cet ordre de
responsabilité :

```mermaid
flowchart TD
  A["calendrier.js<br/>Quel jour liturgique ?<br/>(temps, semaine, saint, préséance, propre OP)"]
  B["aelf.js<br/>Textes propres du jour sur api.aelf.org<br/>(gardés en mémoire pour le hors-connexion)"]
  C["textes.js<br/>Retrouve chaque psaume / lecture<br/>dans VOTRE traduction (BJ)"]
  G["gouzes.js, milieu.js, capitules.js,<br/>bouchet.js, latin.js<br/>Répartitions et ajouts propres"]
  P["partitions.js<br/>Quelle partition sous quel texte ?"]
  OF["offices.js<br/>Assemble l'office complet"]
  APP["app.js<br/>Affichage, réglages, export PDF / Word"]
  A --> B --> C --> OF
  G --> OF
  P --> OF
  OF --> APP
```

- **`calendrier.js`** — calcule Pâques et tout le temporal, lit le sanctoral (`sanctoral.json`, relevé sur
  l'AELF 2018-2027) et le propre OP, applique la préséance et les transferts. Il marche pour n'importe
  quelle année.
- **`aelf.js`** — l'AELF ne publie qu'environ 9 mois à l'avance. Au-delà, le programme prend *le même jour
  liturgique* d'une année déjà publiée. Les réponses sont gardées dans le navigateur.
- **`textes.js`** — fait le lien entre une référence de l'AELF (« Ps 118-18 », « Cantique Ap 4-5 »…) et
  votre psautier, en gardant le gras des inflexions et la disposition des strophes.
- **`offices.js`** — le chef d'orchestre : lectures, laudes, milieu du jour, vêpres, complies, selon la
  *version* choisie (romaine, romain gouzantin — partitions repliées —, gouzantine, latin-français, 100 % AELF).
- **`partitions.js`** — choisit les images des carnets (Perdrix, Sainte-Baume, Heures grégoriennes,
  complies de Bordeaux, milieu du jour de Marseille) et les place sous le texte, en sections repliables.
- **`app.js`** — l'écran, les réglages, et la fabrication des **PDF** (impression du navigateur) et des
  **Word** (`docx.js`, qui écrit le fichier `.docx` directement).
- **`sw.js` + `horsligne.js`** — permettent d'*enregistrer* une période (jusqu'à 100 jours) pour lire sans
  réseau.
- **`signaler.js`** — la bulle « Signaler » : l'erreur est gardée sur l'appareil puis envoyée à Azure.

---

## 4. L'atelier : comment les données sont fabriquées

Rien de cela ne tourne en ligne. On relance un programme **seulement si sa source change**.

| Ce qu'on veut refaire | Programme (dans `outils/`) | Produit |
|---|---|---|
| Psautier BJ et Bible BJ | `construire_donnees.py` (+ `lire_word.py`) | `site/donnees/psautier.json`, `bible/` |
| Psautier AELF à inflexions | `construire_psautier_aelf.py` | `psautier_aelf.json` |
| Psaumes latins (Office des lectures) | `construire_psautier_latin.py` | `psautier_latin.json` |
| Calendrier des saints | `construire_calendrier.py` (+ `corrections_sanctoral.json`) | `sanctoral.json` |
| Liturgie de Gouzes | `construire_gouzes.py` | `gouzes.json` |
| Milieu du jour, complies, capitules | `construire_milieu.py`, `construire_complies.py`, `capitules_province.py` | `milieu.json`, `complies.json`, `capitules.json` |
| Lectionnaire Bouchet | `construire_bouchet.py` | `bouchet.json` |
| Prière du président | `construire_president.py` | `president.json` |
| Images des carnets | `rendre_partitions.sh` → `decouper_partitions.py` → `marquer_musique.py` → `hymnes_pages.py`, `antiennes_pages.py` | `partitions/<carnet>/*.jpg` + `pieces.json` |
| Fêtes des carnets (ordo) | `construire_ordo.py` (+ `ordo_noel.py`) | `partitions/ordo.json` |
| Heures grégoriennes | `indexer_heures_gregoriennes.py`, `construire_offices_latins.py` | `partitions/hg/` |
| Liste des images vraiment utilisées | `node outils/releve_images.mjs` (20-40 min) | `partitions/images-utilisees.json` |

Vos corrections à la main de partitions vont dans `partitions/corrections.json` et
`partitions/corrections/` (voir `CORRIGER-UNE-PARTITION.md`) : elles **ne sont jamais écrasées** par les
programmes.

**Contrôles** : les fichiers de `tests/` (`node tests/calendrier.test.js`, `offices.test.js`,
`milieu.test.js`, etc.) vérifient par exemple que le calendrier ne diffère jamais de celui de l'AELF sur
2018-2027, ou que chaque référence trouve son texte. On les lance après toute modification.

---

## 5. Azure : ce qui est en ligne et où

Tout est dans l'abonnement « Azure subscription 1 », groupe de ressources **`breviaire`**.

| Élément Azure | Nom | Rôle | Coût |
|---|---|---|---|
| **Static Web App** (offre Standard, Central US) | `breviaire-dominicain` | Sert le site : pages, scripts, textes (~20 Mo). Adresse : https://calm-flower-052e85c10.4.azurestaticapps.net | ≈ 9 $/mois |
| **Compte de stockage « entrepôt »** (France Central) | `breviairefichiers` | Images des partitions et données de la Bible (~450 Mo), trop lourdes pour la Static Web App (limite 500 Mo) | quelques centimes/mois |
| **Fonction gérée** (dans la Static Web App) | `api/signalements` | Reçoit les signalements d'erreur | incluse |
| **Compte de stockage « signalements »** (France Central) | `breviairesignal6065`, table `signalements` | Garde les signalements reçus | quelques centimes/mois |

Réglages importants, à voir dans le portail Azure :

- `site/staticwebapp.config.json` : en-têtes (interdiction d'indexation par les moteurs de recherche,
  durées de mémoire du navigateur).
- Variables de la Static Web App : `SIGNALEMENTS_STOCKAGE` (accès à la table) et `SIGNALEMENTS_CLE` (clé
  pour lire les signalements, copie locale dans `.cle_signalements.txt`).
- **Mot de passe du site** : la protection par mot de passe est actuellement **désactivée** (le site répond
  sans mot de passe). Elle se rétablit dans le portail : Static Web App → *Paramètres* → *Configuration* →
  *Protection par mot de passe*.
- L'entrepôt n'accepte les demandes que venant du site en ligne et du Mac (`localhost:8765`).

### Publier une nouvelle version

```bash
bash outils/publier_azure.sh --essai
```
prépare tout et affiche la taille, **sans rien envoyer**. Puis, pour de vrai :

```bash
bash outils/publier_azure.sh
```

Le programme : vérifie que la liste des images est à jour, copie `site/` dans un dossier temporaire, envoie
les images et la Bible dans l'entrepôt (seulement ce qui a changé), puis le reste dans la Static Web App.
Il faut avoir fait une fois `az login` sur le Mac. Détails : `MISE-EN-LIGNE-AZURE.md`.

---

## 6. Et GitHub, à quoi ça sert ?

**GitHub est un coffre-fort à versions**, en ligne. On y dépose des « photographies » successives du
dossier (*commits*), chacune avec une phrase qui dit ce qui a changé. Cela sert à :

- **sauvegarder** : si le Mac est perdu, tout le travail est récupérable ;
- **revenir en arrière** : retrouver le dossier tel qu'il était le 16 novembre, ou voir ce qu'une
  modification a changé ;
- **transmettre** : un frère, ou un informaticien, peut récupérer le projet complet d'un coup.

GitHub **n'est pas** le site : le public ne voit rien de GitHub. Le site, lui, est sur Azure. Le dépôt
GitHub de ce projet (`frwandrille/psautier`) est **privé** : seul son propriétaire y a accès. Il doit le
rester, car il contient les textes de la Bible de Jérusalem, les polices Kepler (licence Adobe) et les
partitions des carnets.

Ce qui n'est **jamais** envoyé sur GitHub (fichier `.gitignore`) : les mots de passe
(`.mot_de_passe_site.txt`), la clé des signalements, les signalements eux-mêmes, les données
reconstruites de la Bible (`bible/data/`), les archives temporaires d'Azure.

---

## 7. Si quelque chose casse

1. Lancer les contrôles de `tests/` : ils disent souvent où.
2. Regarder les signalements : page `signalements.html` du site (avec la clé).
3. Lire `CLAUDE.md` : chaque piège déjà rencontré y est noté (serveur local, cache du navigateur
   — changer `?v=N` dans `index.html` —, découpage des complies à ne pas relancer, etc.).
4. Revenir à la dernière version enregistrée sur GitHub si une modification a tout cassé.
